
This directory contains the BART source code and an example
of how to create an executable for BART that does not require
R.  This is may be useful when you are trying to debug your
R code that generates a seg-fault with BART.  Or for other
reasons such as calling BART from another language like 
python.  See the Makefile for building an executable.  For
example, "make pmain.out".
